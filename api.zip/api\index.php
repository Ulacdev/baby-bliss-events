<?php
// Simple index.php to test if PHP works
echo "PHP is working! Current time: " . date('Y-m-d H:i:s');
echo "<br>Request method: " . $_SERVER['REQUEST_METHOD'];
echo "<br>Server software: " . $_SERVER['SERVER_SOFTWARE'];
?>